import { useState, useRef, useEffect, ChangeEvent, DragEvent, FormEvent } from 'react';
import { 
  Play, Pause, SkipBack, SkipForward, RotateCcw, RotateCw, Volume2, VolumeX, 
  Maximize, Minimize, FolderOpen, Sun, Moon, 
  Eye, Monitor, Music, Film, List, ChevronUp, ChevronLeft, ChevronRight,
  FastForward, Rewind, Clock,
  Tv, Share2, Info, Sparkles, Zap, Activity,
  Crown, Headphones, Compass, Languages, Captions,
  Lock, Unlock, ShieldCheck, Target, X, ExternalLink, Chrome,
  CheckCircle2, CreditCard, AlertCircle, ShoppingBag, User, Settings, LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import React, { Component, ErrorInfo, ReactNode } from 'react';
import { auth, db } from './firebase';
import { 
  onAuthStateChanged, 
  signOut,
  User as FirebaseUser,
  GoogleAuthProvider,
  signInWithPopup
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  onSnapshot 
} from 'firebase/firestore';

class ErrorBoundary extends React.Component<{ children: ReactNode }, { hasError: boolean, error: Error | null }> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="fixed inset-0 z-[200] bg-black flex items-center justify-center p-6 text-center">
          <div className="max-w-md p-8 bg-surface border border-red-500/20 rounded-[32px] shadow-2xl">
            <div className="w-16 h-16 bg-red-500/10 rounded-2xl flex items-center justify-center mb-6 mx-auto">
              <Activity size={32} className="text-red-500" />
            </div>
            <h2 className="text-2xl font-display font-black mb-4">Something went wrong</h2>
            <p className="text-white/60 text-sm mb-6">
              The application encountered an unexpected error. Please try refreshing the page.
            </p>
            <button 
              onClick={() => window.location.reload()}
              className="px-8 py-3 bg-white text-black font-bold rounded-xl hover:bg-white/90 transition-colors"
            >
              Reload App
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

type PlaybackMode = 'video' | 'audio';

interface MediaFile {
  name: string;
  url: string;
  type: PlaybackMode;
  size: string;
  format: string;
  thumbnail?: string;
  resolution?: string;
  bitrate?: string;
  codec?: string;
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export default function App() {
  const mainRef = useRef<HTMLElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [currentFile, setCurrentFile] = useState<MediaFile | null>(null);
  const [playlist, setPlaylist] = useState<MediaFile[]>([]);
  const [activeCategory, setActiveCategory] = useState<'all' | 'video' | 'audio'>('all');
  const [showPlaylist, setShowPlaylist] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const directoryInputRef = useRef<HTMLInputElement>(null);
  
  // Display Features
  const [hdrMode, setHdrMode] = useState(false);
  const [proVisuals, setProVisuals] = useState(false);
  const [blueLightFilter, setBlueLightFilter] = useState(false);
  const [autoNext, setAutoNext] = useState(true);
  const [audioMode, setAudioMode] = useState<'off' | 'RD' | 'KD' | 'PD' | 'SD'>('off');
  const analyserRef = useRef<AnalyserNode | null>(null);
  const hpfNodeRef = useRef<BiquadFilterNode | null>(null);
  const bassNodeRef = useRef<BiquadFilterNode | null>(null);
  const clarityNodeRef = useRef<BiquadFilterNode | null>(null);
  const compressorNodeRef = useRef<DynamicsCompressorNode | null>(null);
  const limiterNodeRef = useRef<DynamicsCompressorNode | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);
  const stereoPannerRef = useRef<StereoPannerNode | null>(null);
  const lfoRef = useRef<OscillatorNode | null>(null);
  const lfoGainRef = useRef<GainNode | null>(null);
  const [eyeCare, setEyeCare] = useState(false);
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [aspectRatio, setAspectRatio] = useState('original');
  const [autoRotate, setAutoRotate] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isSeeking, setIsSeeking] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [hasConsented, setHasConsented] = useState(() => {
    return localStorage.getItem('cineMax_consent') === 'true';
  });
  const [showUI, setShowUI] = useState(true);
  const [isLocked, setIsLocked] = useState(false);
  const [zoomScale, setZoomScale] = useState(1);
  const [showZoomIndicator, setShowZoomIndicator] = useState(false);
  const uiTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const pinchStartDistanceRef = useRef<number | null>(null);
  const pinchStartScaleRef = useRef<number>(1);
  const [gestureState, setGestureState] = useState<{
    type: 'brightness' | 'volume' | null;
    value: number;
    show: boolean;
    startY: number;
    startValue: number;
    hasMoved: boolean;
  }>({
    type: null,
    value: 0,
    show: false,
    startY: 0,
    startValue: 0,
    hasMoved: false
  });
  
  // Spatial Features
  const [spatialAudio, setSpatialAudio] = useState(false);
  const [headRotation, setHeadRotation] = useState({ alpha: 0, beta: 0, gamma: 0 });

  // Media Tracks
  const [audioTracks, setAudioTracks] = useState<any[]>([]);
  const [subtitleTracks, setSubtitleTracks] = useState<any[]>([]);
  const [currentAudioTrack, setCurrentAudioTrack] = useState(0);
  const [currentSubtitleTrack, setCurrentSubtitleTrack] = useState(-1); // -1 for off
  const [showAudioMenu, setShowAudioMenu] = useState(false);
  const [showSubtitleMenu, setShowSubtitleMenu] = useState(false);

  // Monetization Features
  const [isPro, setIsPro] = useState(() => localStorage.getItem('cineMax_isPro') === 'true');
  const [showUpgradeModal, setShowUpgradeModal] = useState(false);
  const [showInterstitial, setShowInterstitial] = useState(false);
  const [adCountdown, setAdCountdown] = useState(5);
  const [lastAdTime, setLastAdTime] = useState(0);

  // Auth & Profile Features
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<any>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    // Keep splash for at least 3 seconds
    const timer = setTimeout(() => setShowSplash(false), 3000);
    return () => clearTimeout(timer);
  }, []);
  const [fullName, setFullName] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState('');

  const videoRef = useRef<HTMLVideoElement>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const pannerRef = useRef<PannerNode | null>(null);
  const sourceRef = useRef<MediaElementAudioSourceNode | null>(null);
  const lastElementRef = useRef<HTMLMediaElement | null>(null);

  useEffect(() => {
    if (!autoRotate) return;

    const handleOrientation = () => {
      const isLandscape = window.innerWidth > window.innerHeight;
      if (isLandscape) {
        setAspectRatio('16:9');
      } else {
        setAspectRatio('9:16');
      }
    };

    window.addEventListener('resize', handleOrientation);
    handleOrientation(); // Initial check

    return () => window.removeEventListener('resize', handleOrientation);
  }, [autoRotate]);

  useEffect(() => {
    let unsubProfile: (() => void) | null = null;
    
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      
      // Clean up previous profile listener if any
      if (unsubProfile) {
        unsubProfile();
        unsubProfile = null;
      }
      
      if (currentUser) {
        // Listen to user profile
        const userDocRef = doc(db, 'users', currentUser.uid);
        unsubProfile = onSnapshot(userDocRef, (docSnap) => {
          if (docSnap.exists()) {
            const profileData = docSnap.data();
            setUserProfile(profileData);
            setIsPro(profileData.isPro);
            localStorage.setItem('cineMax_isPro', profileData.isPro ? 'true' : 'false');
          } else {
            setUserProfile(null);
            setShowSettings(true);
          }
        }, (error) => {
          // Only report error if user is still logged in
          if (auth.currentUser) {
            handleFirestoreError(error, OperationType.GET, `users/${currentUser.uid}`);
          }
        });
      } else {
        setUserProfile(null);
        setIsPro(false);
        localStorage.setItem('cineMax_isPro', 'false');
      }
    });
    
    return () => {
      unsubscribe();
      if (unsubProfile) unsubProfile();
    };
  }, []);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (showInterstitial && adCountdown > 0) {
      timer = setInterval(() => {
        setAdCountdown(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [showInterstitial, adCountdown]);

  const handleUpgrade = async () => {
    if (!user) {
      setShowUpgradeModal(false);
      setShowSettings(true);
      return;
    }

    try {
      const response = await fetch('/api/create-razorpay-order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create order');
      }

      const order = await response.json();
      
      const options = {
        key: order.key_id,
        amount: order.amount,
        currency: order.currency,
        name: "CineMax PRO",
        description: "Unlock all premium features",
        order_id: order.id,
        handler: async (response: any) => {
          // Success callback
          try {
            const userDocRef = doc(db, 'users', user.uid);
            await setDoc(userDocRef, { isPro: true }, { merge: true });
            setIsPro(true);
            localStorage.setItem('cineMax_isPro', 'true');
            setShowUpgradeModal(false);
            alert('Payment Successful! You are now a PRO user.');
          } catch (error) {
            console.error('Error finalizing PRO status:', error);
          }
        },
        prefill: {
          name: user.displayName || "",
          email: user.email || "",
        },
        theme: {
          color: "#6366f1",
        },
      };

      const rzp = new (window as any).Razorpay(options);
      rzp.open();
    } catch (error: any) {
      console.error('Payment Error:', error);
      alert(`Payment Error: ${error.message}`);
    }
  };

  // Load Razorpay Script
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  const handleGoogleSignIn = async () => {
    setAuthError('');
    setAuthLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      if (result.user && !fullName) {
        setFullName(result.user.displayName || '');
      }
      // onAuthStateChanged will handle the rest
    } catch (error: any) {
      console.error("Google Sign In Error:", error);
      setAuthError(error.message || 'Failed to sign in with Google');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleCreateProfile = async () => {
    if (!user) return;
    setAuthError('');
    setAuthLoading(true);
    try {
      const userDocRef = doc(db, 'users', user.uid);
      const profileData: any = {
        fullName,
        isPro: false,
        createdAt: new Date().toISOString()
      };
      
      if (user.email) {
        profileData.email = user.email;
      }

      try {
        await setDoc(userDocRef, profileData);
        setUserProfile(profileData);
        setShowSettings(false);
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
        setAuthError('Failed to create profile');
      }
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setShowSettings(false);
    } catch (error) {
      console.error("Logout error:", error);
    }
  };

  const checkProAccess = (featureName: string, action: () => void) => {
    if (isPro) {
      action();
    } else {
      setShowUpgradeModal(true);
    }
  };

  const handleSubtitleChange = (index: number) => {
    if (!videoRef.current) return;
    
    // Disable all tracks first
    Array.from(videoRef.current.textTracks).forEach(t => t.mode = 'disabled');
    
    if (index !== -1) {
      const track = subtitleTracks[index];
      if (track) {
        track.mode = 'showing';
      }
    }
    setCurrentSubtitleTrack(index);
    setShowSubtitleMenu(false);
  };

  const handleAudioChange = (index: number) => {
    if (!videoRef.current) return;
    const tracks = (videoRef.current as any).audioTracks;
    if (tracks) {
      for (let i = 0; i < tracks.length; i++) {
        tracks[i].enabled = (i === index);
      }
      setCurrentAudioTrack(index);
    }
    setShowAudioMenu(false);
  };

  useEffect(() => {
    if (pannerRef.current) {
      pannerRef.current.panningModel = spatialAudio ? 'HRTF' : 'equalpower';
      if (!spatialAudio) {
        // Reset to center when spatial is off
        pannerRef.current.positionX.value = 0;
        pannerRef.current.positionY.value = 0;
        pannerRef.current.positionZ.value = -1;
      }
    }

    if (spatialAudio) {
      const handleOrientation = (e: DeviceOrientationEvent) => {
        if (e.alpha !== null && e.beta !== null && e.gamma !== null) {
          setHeadRotation({ alpha: e.alpha, beta: e.beta, gamma: e.gamma });
          if (pannerRef.current) {
            // Map rotation to 3D space
            const x = Math.sin(e.gamma * Math.PI / 180) * 5;
            const z = Math.cos(e.gamma * Math.PI / 180) * 5;
            pannerRef.current.positionX.value = x;
            pannerRef.current.positionZ.value = -z;
          }
        }
      };

      window.addEventListener('deviceorientation', handleOrientation);
      return () => window.removeEventListener('deviceorientation', handleOrientation);
    }
  }, [spatialAudio]);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.playbackRate = playbackSpeed;
    }
  }, [playbackSpeed]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.volume = volume;
      videoRef.current.muted = isMuted;
    }
  }, [volume, isMuted]);

  const resetUITimer = () => {
    if (uiTimeoutRef.current) clearTimeout(uiTimeoutRef.current);
    if (isPlaying && !showPlaylist) {
      uiTimeoutRef.current = setTimeout(() => {
        setShowUI(false);
      }, 2000);
    }
  };

  useEffect(() => {
    if (isPlaying) {
      resetUITimer();
    } else {
      if (uiTimeoutRef.current) clearTimeout(uiTimeoutRef.current);
      setShowUI(true);
    }
    return () => {
      if (uiTimeoutRef.current) clearTimeout(uiTimeoutRef.current);
    };
  }, [isPlaying, showPlaylist]);

  const togglePlay = () => {
    if (isLocked) {
      setShowUI(true);
      resetUITimer();
      return;
    }

    // If UI was hidden, just show it and don't toggle play
    if (!showUI) {
      setShowUI(true);
      resetUITimer();
      return;
    }

    // If we were just dragging, don't toggle play
    if (gestureState.hasMoved) return;

    if (!currentFile) {
      fileInputRef.current?.click();
      return;
    }

    const now = Date.now();
    if (!isPro && !isPlaying && (now - lastAdTime > 900000)) {
      setShowInterstitial(true);
      setAdCountdown(5);
      setLastAdTime(now);
      return;
    }

    if (videoRef.current) {
      // Initialize Audio Context on first play
      if (!audioCtxRef.current) {
        initAudioContext();
      } else if (audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }

      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const initAudioContext = (initialMode?: string) => {
    if (!videoRef.current) return;
    
    // If we already have a context and it's the same element, don't re-init
    if (audioCtxRef.current && lastElementRef.current === videoRef.current) return;

    try {
      // If element changed, we need to re-create the source node
      if (audioCtxRef.current && lastElementRef.current !== videoRef.current) {
        if (sourceRef.current) {
          sourceRef.current.disconnect();
        }
        const source = audioCtxRef.current.createMediaElementSource(videoRef.current as any);
        sourceRef.current = source;
        lastElementRef.current = videoRef.current;
        
        // Re-connect to the existing chain
        if (bassNodeRef.current) {
          source.connect(bassNodeRef.current);
        }
        return;
      }

      const AudioContextClass = (window.AudioContext || (window as any).webkitAudioContext);
      const ctx = new AudioContextClass();
      audioCtxRef.current = ctx;
      lastElementRef.current = videoRef.current;

      const source = ctx.createMediaElementSource(videoRef.current as any);
      sourceRef.current = source;

      // Audio Engine Nodes
      const hpf = ctx.createBiquadFilter();
      hpf.type = 'highpass';
      hpf.frequency.value = 35; // Remove sub-bass rumble
      hpfNodeRef.current = hpf;

      const bass = ctx.createBiquadFilter();
      bass.type = 'lowshelf';
      bass.frequency.value = 150;
      bassNodeRef.current = bass;

      const clarity = ctx.createBiquadFilter();
      clarity.type = 'highshelf';
      clarity.frequency.value = 3000;
      clarityNodeRef.current = clarity;

      const compressorNode = ctx.createDynamicsCompressor();
      compressorNode.knee.value = 30;
      compressorNode.ratio.value = 12;
      compressorNode.attack.value = 0.003;
      compressorNode.release.value = 0.25;
      compressorNodeRef.current = compressorNode;

      const stereoPanner = ctx.createStereoPanner();
      stereoPanner.pan.value = 0;
      stereoPannerRef.current = stereoPanner;

      const lfo = ctx.createOscillator();
      const lfoGain = ctx.createGain();
      lfo.frequency.value = 0.2;
      lfoGain.gain.value = 0;
      lfo.connect(lfoGain);
      lfoGain.connect(stereoPanner.pan);
      lfo.start();
      lfoRef.current = lfo;
      lfoGainRef.current = lfoGain;

      const masterGain = ctx.createGain();
      masterGain.gain.value = 1.0;
      masterGainRef.current = masterGain;

      // Apply initial settings based on mode
      const applySettings = (mode: string) => {
        const now = ctx.currentTime;
        switch(mode) {
          case 'RD':
            bass.gain.setTargetAtTime(6, now, 0.1);
            clarity.gain.setTargetAtTime(4, now, 0.1);
            compressorNode.threshold.setTargetAtTime(-20, now, 0.1);
            lfoGain.gain.setTargetAtTime(0.1, now, 0.1);
            masterGain.gain.setTargetAtTime(1.1, now, 0.1);
            break;
          case 'KD':
            bass.gain.setTargetAtTime(12, now, 0.1);
            clarity.gain.setTargetAtTime(2, now, 0.1);
            compressorNode.threshold.setTargetAtTime(-25, now, 0.1);
            lfoGain.gain.setTargetAtTime(0.05, now, 0.1);
            masterGain.gain.setTargetAtTime(1.0, now, 0.1);
            break;
          case 'PD':
            bass.gain.setTargetAtTime(2, now, 0.1);
            clarity.gain.setTargetAtTime(10, now, 0.1);
            compressorNode.threshold.setTargetAtTime(-30, now, 0.1);
            lfoGain.gain.setTargetAtTime(0.15, now, 0.1);
            masterGain.gain.setTargetAtTime(1.1, now, 0.1);
            break;
          case 'SD':
            bass.gain.setTargetAtTime(4, now, 0.1);
            clarity.gain.setTargetAtTime(6, now, 0.1);
            compressorNode.threshold.setTargetAtTime(-15, now, 0.1);
            lfoGain.gain.setTargetAtTime(0.25, now, 0.1);
            masterGain.gain.setTargetAtTime(1.1, now, 0.1);
            break;
          default:
            bass.gain.setTargetAtTime(0, now, 0.1);
            clarity.gain.setTargetAtTime(0, now, 0.1);
            compressorNode.threshold.setTargetAtTime(0, now, 0.1);
            lfoGain.gain.setTargetAtTime(0, now, 0.1);
            masterGain.gain.setTargetAtTime(1.0, now, 0.1);
        }
      };

      applySettings(initialMode || audioMode);

      const limiter = ctx.createDynamicsCompressor();
      limiter.threshold.value = -1;
      limiter.knee.value = 0;
      limiter.ratio.value = 20;
      limiter.attack.value = 0.001;
      limiter.release.value = 0.1;
      limiterNodeRef.current = limiter;

      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      analyserRef.current = analyser;

      // Chain: Source -> HPF -> Bass -> Clarity -> Compressor -> StereoPanner -> MasterGain -> Analyser -> Limiter -> Destination
      source.connect(hpf);
      hpf.connect(bass);
      bass.connect(clarity);
      clarity.connect(compressorNode);
      compressorNode.connect(stereoPanner);
      stereoPanner.connect(masterGain);
      masterGain.connect(analyser);
      analyser.connect(limiter);
      limiter.connect(ctx.destination);

    } catch (e) {
      console.error("Failed to initialize RD Audio Engine:", e);
    }
  };

  const cycleAudioMode = () => {
    const modes: ('off' | 'RD' | 'KD' | 'PD' | 'SD')[] = ['off', 'RD', 'KD', 'PD', 'SD'];
    const currentIndex = modes.indexOf(audioMode);
    const nextMode = modes[(currentIndex + 1) % modes.length];
    setAudioMode(nextMode);

    if (audioCtxRef.current) {
      if (audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }

      const now = audioCtxRef.current.currentTime;
      const bass = bassNodeRef.current;
      const clarity = clarityNodeRef.current;
      const compressor = compressorNodeRef.current;
      const stereoPanner = stereoPannerRef.current;
      const lfoGain = lfoGainRef.current;
      const masterGain = masterGainRef.current;

      if (bass && clarity && compressor && masterGain) {
        switch(nextMode) {
          case 'RD':
            bass.gain.setTargetAtTime(6, now, 0.1);
            clarity.gain.setTargetAtTime(4, now, 0.1);
            compressor.threshold.setTargetAtTime(-20, now, 0.1);
            if (stereoPanner) stereoPanner.pan.setTargetAtTime(0, now, 0.1);
            if (lfoGain) lfoGain.gain.setTargetAtTime(0.1, now, 0.1);
            masterGain.gain.setTargetAtTime(1.1, now, 0.1);
            break;
          case 'KD':
            bass.gain.setTargetAtTime(12, now, 0.1);
            clarity.gain.setTargetAtTime(2, now, 0.1);
            compressor.threshold.setTargetAtTime(-25, now, 0.1);
            if (stereoPanner) stereoPanner.pan.setTargetAtTime(0, now, 0.1);
            if (lfoGain) lfoGain.gain.setTargetAtTime(0.05, now, 0.1);
            masterGain.gain.setTargetAtTime(1.0, now, 0.1);
            break;
          case 'PD':
            bass.gain.setTargetAtTime(2, now, 0.1);
            clarity.gain.setTargetAtTime(10, now, 0.1);
            compressor.threshold.setTargetAtTime(-30, now, 0.1);
            if (stereoPanner) stereoPanner.pan.setTargetAtTime(0, now, 0.1);
            if (lfoGain) lfoGain.gain.setTargetAtTime(0.15, now, 0.1);
            masterGain.gain.setTargetAtTime(1.1, now, 0.1);
            break;
          case 'SD':
            bass.gain.setTargetAtTime(4, now, 0.1);
            clarity.gain.setTargetAtTime(6, now, 0.1);
            compressor.threshold.setTargetAtTime(-15, now, 0.1);
            if (stereoPanner) stereoPanner.pan.setTargetAtTime(0, now, 0.1);
            if (lfoGain) lfoGain.gain.setTargetAtTime(0.25, now, 0.1);
            masterGain.gain.setTargetAtTime(1.1, now, 0.1);
            break;
          default:
            bass.gain.setTargetAtTime(0, now, 0.1);
            clarity.gain.setTargetAtTime(0, now, 0.1);
            compressor.threshold.setTargetAtTime(0, now, 0.1);
            if (stereoPanner) stereoPanner.pan.setTargetAtTime(0, now, 0.1);
            if (lfoGain) lfoGain.gain.setTargetAtTime(0, now, 0.1);
            masterGain.gain.setTargetAtTime(1.0, now, 0.1);
        }
      }
    } else if (nextMode !== 'off') {
      initAudioContext(nextMode);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current && !isSeeking) {
      setCurrentTime(videoRef.current.currentTime);
    }
  };

  const handleLoadedMetadata = () => {
    if (videoRef.current) {
      setDuration(videoRef.current.duration);
      
      const updateTracks = () => {
        // Audio Tracks (Safari/Edge only)
        if ((videoRef.current as any).audioTracks) {
          const tracks = Array.from((videoRef.current as any).audioTracks);
          setAudioTracks(tracks);
          const activeIndex = tracks.findIndex((t: any) => t.enabled);
          setCurrentAudioTrack(activeIndex !== -1 ? activeIndex : 0);
        } else {
          setAudioTracks([]);
        }

        // Text Tracks (Subtitles)
        if (videoRef.current?.textTracks) {
          const tracks = Array.from(videoRef.current.textTracks).filter(t => t.kind === 'subtitles' || t.kind === 'captions');
          setSubtitleTracks(tracks);
          const activeIndex = tracks.findIndex(t => t.mode === 'showing');
          setCurrentSubtitleTrack(activeIndex);
        } else {
          setSubtitleTracks([]);
        }
      };

      updateTracks();

      // Listen for track changes (some browsers populate these later)
      if ((videoRef.current as any).audioTracks) {
        (videoRef.current as any).audioTracks.onaddtrack = updateTracks;
        (videoRef.current as any).audioTracks.onremovetrack = updateTracks;
      }
      if (videoRef.current.textTracks) {
        videoRef.current.textTracks.onaddtrack = updateTracks;
        videoRef.current.textTracks.onremovetrack = updateTracks;
      }

      // Extract additional metadata
      if (currentFile) {
        const updatedFile = { ...currentFile };
        
        if (currentFile.type === 'video') {
          updatedFile.resolution = `${videoRef.current.videoWidth}x${videoRef.current.videoHeight}`;
          // Codec info is limited in standard HTML5, but we can try to infer or use defaults
          updatedFile.codec = 'H.264 / AVC'; 
        } else {
          updatedFile.bitrate = '320 kbps'; // Placeholder as bitrate isn't directly available
          updatedFile.codec = 'MPEG-4 / AAC';
        }
        
        setCurrentFile(updatedFile);
        setPlaylist(prev => prev.map(f => f.url === updatedFile.url ? updatedFile : f));
      }
    }
  };

  const handleSeek = (e: FormEvent<HTMLInputElement> | ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat((e.target as HTMLInputElement).value);
    if (videoRef.current) {
      videoRef.current.currentTime = time;
      setCurrentTime(time);
    }
  };

  const skip = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime += seconds;
    }
  };

  const skipFrame = (direction: 'forward' | 'backward') => {
    if (videoRef.current) {
      const frameTime = 1 / 30; // Assuming 30fps
      videoRef.current.currentTime += direction === 'forward' ? frameTime : -frameTime;
    }
  };

  const playNext = () => {
    if (playlist.length <= 1) return;
    
    const currentIndex = playlist.findIndex(f => f.url === currentFile?.url);
    const nextIndex = (currentIndex + 1) % playlist.length;
    setCurrentFile(playlist[nextIndex]);
    setIsPlaying(true); // Auto play next
  };

  const playPrevious = () => {
    if (playlist.length <= 1) return;
    const currentIndex = playlist.findIndex(f => f.url === currentFile?.url);
    const prevIndex = (currentIndex - 1 + playlist.length) % playlist.length;
    setCurrentFile(playlist[prevIndex]);
    setIsPlaying(false);
  };

  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      Array.from(files).forEach(file => {
        if (file.type.startsWith('video/') || file.type.startsWith('audio/')) {
          addFileToPlaylist(file);
        }
      });
    }
  };

  const handleFolderUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const mediaFiles = Array.from(files).filter(file => 
        file.type.startsWith('video/') || file.type.startsWith('audio/')
      );
      
      mediaFiles.forEach(file => addFileToPlaylist(file, false));
      
      if (mediaFiles.length > 0 && !currentFile) {
        const first = mediaFiles[0];
        const url = URL.createObjectURL(first);
        const newFile: MediaFile = {
          name: first.name,
          url: url,
          type: first.type.startsWith('audio') ? 'audio' : 'video',
          size: `${(first.size / (1024 * 1024)).toFixed(1)} MB`,
          format: first.name?.split('.').pop()?.toUpperCase() || 'UNK'
        };
        setCurrentFile(newFile);
      }
    }
  };

  const generateThumbnail = (file: File): Promise<string | undefined> => {
    return new Promise((resolve) => {
      if (!file.type.startsWith('video/')) {
        resolve(undefined);
        return;
      }

      const video = document.createElement('video');
      video.preload = 'metadata';
      video.muted = true;
      video.playsInline = true;
      const url = URL.createObjectURL(file);
      video.src = url;

      video.onloadedmetadata = () => {
        // Seek to 1 second or 10% of duration if duration is small
        video.currentTime = Math.min(1, video.duration / 2 || 0);
      };

      video.onseeked = () => {
        const canvas = document.createElement('canvas');
        canvas.width = 160;
        canvas.height = 90;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          const thumbnail = canvas.toDataURL('image/jpeg', 0.7);
          URL.revokeObjectURL(url);
          resolve(thumbnail);
        } else {
          URL.revokeObjectURL(url);
          resolve(undefined);
        }
      };

      video.onerror = () => {
        URL.revokeObjectURL(url);
        resolve(undefined);
      };
    });
  };

  const addFileToPlaylist = (file: File, shouldPlay: boolean = true) => {
    const url = URL.createObjectURL(file);
    const newFile: MediaFile = {
      name: file.name,
      url: url,
      type: file.type.startsWith('audio') ? 'audio' : 'video',
      size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
      format: file.name?.split('.').pop()?.toUpperCase() || 'UNK'
    };

    setPlaylist(prev => {
      // Avoid duplicates by name and size for now
      if (prev.some(f => f.name === newFile.name && f.size === newFile.size)) return prev;
      return [newFile, ...prev];
    });

    if (shouldPlay) {
      setCurrentFile(newFile);
      setIsPlaying(false);
    }

    // Generate thumbnail asynchronously
    if (file.type.startsWith('video/')) {
      generateThumbnail(file).then(thumbnail => {
        if (thumbnail) {
          setPlaylist(prev => prev.map(f => 
            (f.name === newFile.name && f.size === newFile.size) 
              ? { ...f, thumbnail } 
              : f
          ));
          setCurrentFile(prev => 
            (prev?.name === newFile.name && prev?.size === newFile.size)
              ? { ...prev, thumbnail }
              : prev
          );
        }
      });
    }
  };

  const handleDragOver = (e: DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files?.[0];
    if (file && (file.type.startsWith('video/') || file.type.startsWith('audio/'))) {
      addFileToPlaylist(file);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getFilterStyle = () => {
    let filters = `brightness(${brightness}%) contrast(${contrast}%)`;
    if (blueLightFilter) filters += ' sepia(0.5) hue-rotate(180deg) saturate(0.8)';
    if (eyeCare) filters += ' sepia(0.2) contrast(1.05) brightness(0.9)';
    if (audioMode !== 'off') filters += ' contrast(1.05) saturate(1.05) brightness(1.02)';
    
    // Enhanced HDR and Pro Visuals with SVG filters for clarity and detail
    if (hdrMode) {
      filters += ' contrast(1.08) saturate(1.15) brightness(1.02) hue-rotate(0.2deg) url(#hdr-enhance)';
    } else if (proVisuals) {
      filters += ' contrast(1.25) saturate(1.24) brightness(1.15) sepia(0.04) hue-rotate(-0.5deg) url(#pro-visuals-enhance)';
    }
    
    return { 
      filter: filters,
      transform: `scale(${zoomScale}) ${spatialAudio ? 'perspective(1000px) rotateX(1deg)' : ''}`,
      transformOrigin: 'center center'
    };
  };

  const getAspectRatioClass = () => {
    switch (aspectRatio) {
      case '16:9': return 'aspect-video';
      case '4:3': return 'aspect-[4/3]';
      case '21:9': return 'aspect-[21/9]';
      case '1:1': return 'aspect-square';
      case '9:16': return 'aspect-[9/16]';
      default: return 'w-full h-full';
    }
  };

  const handleGestureStart = (clientX: number, clientY: number, touches?: React.TouchList) => {
    if (isLocked) {
      setShowUI(true);
      resetUITimer();
      return;
    }

    if (touches && touches.length === 2) {
      const dist = Math.hypot(
        touches[0].clientX - touches[1].clientX,
        touches[0].clientY - touches[1].clientY
      );
      pinchStartDistanceRef.current = dist;
      pinchStartScaleRef.current = zoomScale;
      setShowZoomIndicator(true);
      return;
    }

    setShowUI(true);
    resetUITimer();
    const mainElement = mainRef.current;
    if (!mainElement) return;

    const rect = mainElement.getBoundingClientRect();
    const x = clientX - rect.left;
    const isLeft = x < rect.width / 2;
    const type = isLeft ? 'brightness' : 'volume';
    const startValue = isLeft ? brightness : volume * 100;

    setGestureState({
      type,
      value: startValue,
      show: true,
      startY: clientY,
      startValue,
      hasMoved: false
    });
  };

  const handleGestureMove = (clientY: number, touches?: React.TouchList) => {
    if (isLocked) return;
    setShowUI(true);
    resetUITimer();

    if (touches && touches.length === 2 && pinchStartDistanceRef.current !== null) {
      const dist = Math.hypot(
        touches[0].clientX - touches[1].clientX,
        touches[0].clientY - touches[1].clientY
      );
      const delta = dist / pinchStartDistanceRef.current;
      const newScale = Math.max(1, Math.min(4, pinchStartScaleRef.current * delta));
      setZoomScale(newScale);
      return;
    }

    if (!gestureState.type || !gestureState.show) return;

    const deltaY = gestureState.startY - clientY;
    if (Math.abs(deltaY) < 5 && !gestureState.hasMoved) return;

    const sensitivity = 0.5; // 1px = 0.5%
    let newValue = gestureState.startValue + (deltaY * sensitivity);
    newValue = Math.max(0, Math.min(100, newValue));

    setGestureState(prev => ({ ...prev, value: newValue, hasMoved: true }));

    if (gestureState.type === 'brightness') {
      setBrightness(newValue);
    } else {
      const newVol = newValue / 100;
      setVolume(newVol);
      if (videoRef.current) {
        videoRef.current.volume = newVol;
      }
    }
  };

  const handleGestureEnd = () => {
    pinchStartDistanceRef.current = null;
    setShowZoomIndicator(false);
    setGestureState(prev => ({ ...prev, show: false, type: null }));
    // Delay resetting hasMoved to prevent the click event from firing togglePlay
    setTimeout(() => {
      setGestureState(prev => ({ ...prev, hasMoved: false }));
    }, 50);
  };

  return (
    <ErrorBoundary>
      <AnimatePresence mode="wait">
        {showSplash ? (
          <motion.div 
            key="splash"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
            className="fixed inset-0 z-[300] bg-[#050508] flex flex-col items-center justify-center p-6"
          >
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 1, type: "spring" }}
              className="relative"
            >
              <div className="w-32 h-32 bg-primary/20 rounded-[40px] flex items-center justify-center overflow-hidden border border-white/10 shadow-[0_0_50px_rgba(0,212,255,0.2)]">
                <Play size={64} className="text-primary fill-primary ml-2" />
              </div>
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                className="absolute -inset-4 border-2 border-dashed border-primary/20 rounded-[48px]"
              />
            </motion.div>
            
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="mt-12 text-center"
            >
              <h1 className="text-4xl font-display font-black tracking-tighter mb-2">
                CineMax <span className="text-primary">PRO</span>
              </h1>
              <div className="flex items-center justify-center gap-2">
                <div className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
                <span className="text-[10px] font-bold text-white/40 uppercase tracking-[0.5em]">
                  Initializing Engine
                </span>
              </div>

              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="mt-12 flex items-center gap-4 opacity-40"
              >
                <span className="text-[8px] font-black tracking-[0.2em] uppercase">Dynamic HDR</span>
                <div className="w-1 h-1 bg-white/20 rounded-full" />
                <span className="text-[8px] font-black tracking-[0.2em] uppercase">Pro Visuals</span>
                <div className="w-1 h-1 bg-white/20 rounded-full" />
                <span className="text-[8px] font-black tracking-[0.2em] uppercase">3D Surround</span>
                <div className="w-1 h-1 bg-white/20 rounded-full" />
                <span className="text-[8px] font-black tracking-[0.2em] uppercase">Eye Care</span>
              </motion.div>
            </motion.div>
          </motion.div>
        ) : (
          <div key="main-app" className="flex flex-col h-screen bg-[#050508] text-white overflow-hidden font-sans">
          <AnimatePresence mode="wait">
            {!hasConsented ? (
          <ConsentScreen 
            key="consent" 
            onAccept={() => {
              localStorage.setItem('cineMax_consent', 'true');
              setHasConsented(true);
            }} 
          />
        ) : (
          isLoading && <LoadingScreen key="loader" />
        )}
      </AnimatePresence>

      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileUpload} 
        className="hidden" 
        accept="video/*,audio/*"
        multiple
      />
      <input 
        type="file" 
        ref={directoryInputRef} 
        onChange={handleFolderUpload} 
        className="hidden" 
        {...({ webkitdirectory: "", directory: "" } as any)}
      />

      {/* Main Player Area */}
      <main 
        ref={mainRef}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onMouseDown={(e) => handleGestureStart(e.clientX, e.clientY)}
        onMouseMove={(e) => handleGestureMove(e.clientY)}
        onMouseUp={handleGestureEnd}
        onMouseLeave={handleGestureEnd}
        onTouchStart={(e) => handleGestureStart(e.touches[0].clientX, e.touches[0].clientY, e.touches)}
        onTouchMove={(e) => handleGestureMove(e.touches[0].clientY, e.touches)}
        onTouchEnd={handleGestureEnd}
        onClick={(e) => {
          // Only toggle UI, don't toggle play
          if (!gestureState.hasMoved) {
            setShowUI(!showUI);
            resetUITimer();
          }
        }}
        className="flex-1 relative flex flex-col items-center justify-center bg-black overflow-hidden select-none"
      >
        {/* AdMob Banner Simulation */}
        {!isPro && (
          <div className="absolute top-20 left-1/2 -translate-x-1/2 z-40 w-full max-w-[320px] h-[50px] bg-white/5 backdrop-blur-md border border-white/10 flex items-center justify-center overflow-hidden">
            <div className="text-[8px] text-white/20 absolute top-1 left-1 font-bold">ADVERTISEMENT</div>
            <div className="flex items-center gap-3 px-4">
              <div className="w-8 h-8 bg-primary/20 rounded-lg flex items-center justify-center">
                <ShoppingBag size={16} className="text-primary" />
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-white/80">Upgrade to CineMax PRO</span>
                <span className="text-[8px] text-white/40">Remove ads and unlock all features</span>
              </div>
              <button 
                onClick={(e) => { e.stopPropagation(); setShowUpgradeModal(true); }}
                className="ml-auto px-3 py-1 bg-primary text-black text-[10px] font-bold rounded-lg"
              >
                BUY
              </button>
            </div>
          </div>
        )}

        {/* AdMob Interstitial Simulation */}
        <AnimatePresence>
          {showInterstitial && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-[200] bg-black flex flex-col items-center justify-center p-6"
            >
              <div className="max-w-md w-full bg-surface border border-white/10 rounded-[32px] p-8 relative overflow-hidden">
                <div className="absolute top-4 right-4">
                  {adCountdown <= 0 ? (
                    <button 
                      onClick={() => { setShowInterstitial(false); togglePlay(); }}
                      className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
                    >
                      <X size={16} />
                    </button>
                  ) : (
                    <div className="w-8 h-8 bg-white/10 rounded-full flex items-center justify-center text-[10px] font-bold">
                      {adCountdown}
                    </div>
                  )}
                </div>
                
                <div className="text-[8px] text-white/20 mb-4 font-bold tracking-widest">ADVERTISEMENT</div>
                
                <div className="aspect-video bg-white/5 rounded-2xl mb-6 flex items-center justify-center relative overflow-hidden">
                  <img 
                    src="https://picsum.photos/seed/ads/800/450" 
                    alt="Ad" 
                    className="w-full h-full object-cover opacity-50"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6">
                    <Crown size={48} className="text-amber-500 mb-4" />
                    <h3 className="text-xl font-display font-black mb-2 tracking-tight">CineMax PRO</h3>
                    <p className="text-sm text-white/60 mb-6">Experience media like never before with Spatial 3D.</p>
                    <button 
                      onClick={handleUpgrade}
                      className="px-8 py-3 bg-amber-500 text-black font-bold rounded-xl shadow-[0_0_30px_rgba(245,158,11,0.4)]"
                    >
                      GET PRO NOW
                    </button>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 bg-primary/20 rounded-xl flex items-center justify-center">
                      <Zap size={20} className="text-primary" />
                    </div>
                    <div>
                      <div className="text-sm font-bold">Ultra Fast Player</div>
                      <div className="text-[10px] text-white/40">No buffering, just quality</div>
                    </div>
                  </div>
                  <button className="text-[10px] font-bold text-primary uppercase tracking-widest">Learn More</button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Upgrade Modal (IAP Simulation) */}
        <AnimatePresence>
          {showUpgradeModal && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-[210] bg-black/80 backdrop-blur-xl flex items-center justify-center p-6"
              onClick={() => setShowUpgradeModal(false)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="max-w-sm w-full bg-surface border border-white/10 rounded-[40px] p-8 shadow-2xl relative overflow-hidden"
              >
                {/* Background Glow */}
                <div className="absolute -top-24 -right-24 w-48 h-48 bg-primary/20 blur-[80px] rounded-full" />
                <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-secondary/20 blur-[80px] rounded-full" />

                <button 
                  onClick={() => setShowUpgradeModal(false)}
                  className="absolute top-6 right-6 text-white/20 hover:text-white transition-colors"
                >
                  <X size={20} />
                </button>

                <div className="flex flex-col items-center text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-amber-400 to-amber-600 rounded-[28px] flex items-center justify-center mb-6 shadow-2xl rotate-3">
                    <Crown size={40} className="text-black" />
                  </div>
                  
                  <h2 className="text-3xl font-display font-black mb-2 tracking-tight">CineMax PRO</h2>
                  <p className="text-white/40 text-sm mb-8">Unlock the ultimate cinematic experience</p>

                  <div className="w-full space-y-4 mb-8">
                    {[
                      { icon: <Headphones size={16} />, text: "RD Audio Engine (World Best)" },
                      { icon: <Sparkles size={16} />, text: "Dynamic HDR Processing" },
                      { icon: <Activity size={16} />, text: "3D Surround Audio Engine" },
                      { icon: <Tv size={16} />, text: "Pro Visuals Simulation" },
                      { icon: <ShieldCheck size={16} />, text: "Zero Advertisements" },
                    ].map((feature, i) => (
                      <div key={i} className="flex items-center gap-3 text-left p-3 bg-white/5 rounded-2xl border border-white/5">
                        <div className="text-amber-500">{feature.icon}</div>
                        <span className="text-xs font-medium text-white/80">{feature.text}</span>
                        <CheckCircle2 size={14} className="ml-auto text-green-500" />
                      </div>
                    ))}
                  </div>

                  <button 
                    onClick={handleUpgrade}
                    className="w-full py-4 bg-white text-black font-black rounded-2xl flex items-center justify-center gap-2 hover:bg-white/90 transition-all active:scale-95 mb-4"
                  >
                    <CreditCard size={18} />
                    UPGRADE NOW - $3.99 / YEAR
                  </button>
                  
                  <button 
                    onClick={() => { setShowUpgradeModal(false); setShowSettings(true); }}
                    className="text-[10px] font-bold text-white/20 uppercase tracking-widest hover:text-white/40 transition-colors"
                  >
                    Restore Purchase
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Settings & Auth Modal */}
        <AnimatePresence>
          {showSettings && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-[220] bg-black/90 backdrop-blur-2xl flex items-center justify-center p-6"
              onClick={() => !authLoading && setShowSettings(false)}
            >
              <motion.div
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.9, y: 20 }}
                onClick={(e) => e.stopPropagation()}
                className="max-w-md w-full bg-surface border border-white/10 rounded-[40px] p-8 shadow-2xl relative overflow-hidden"
              >
                <button 
                  onClick={() => setShowSettings(false)}
                  className="absolute top-6 right-6 text-white/20 hover:text-white transition-colors"
                  disabled={authLoading}
                >
                  <X size={20} />
                </button>

                <div className="flex flex-col items-center">
                  <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center mb-6">
                    <User size={32} className="text-primary" />
                  </div>

                  {!user ? (
                    <div className="w-full text-center">
                      <h2 className="text-2xl font-display font-black mb-2 tracking-tight">
                        Welcome to CineMax
                      </h2>
                      <p className="text-white/40 text-sm mb-8">
                        Sign in to sync your PRO status and playlists
                      </p>

                      <div className="space-y-4 w-full">
                        {authError && (
                          <div className="flex items-center gap-2 text-red-500 text-xs bg-red-500/10 p-3 rounded-xl">
                            <AlertCircle size={14} />
                            {authError}
                          </div>
                        )}

                        <button 
                          onClick={handleGoogleSignIn}
                          disabled={authLoading}
                          className="w-full py-4 bg-white/5 border border-white/10 text-white font-bold rounded-2xl flex items-center justify-center gap-3 hover:bg-white/10 transition-all active:scale-95 disabled:opacity-50"
                        >
                          {authLoading ? (
                            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          ) : (
                            <>
                              <Chrome size={20} className="text-primary" />
                              Continue with Google
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  ) : !userProfile ? (
                    <div className="w-full text-center">
                      <h2 className="text-2xl font-display font-black mb-2 tracking-tight">Complete Profile</h2>
                      <p className="text-white/40 text-sm mb-8">Tell us your name to get started</p>

                      <div className="space-y-4 w-full">
                        <div className="relative">
                          <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/20" />
                          <input 
                            type="text"
                            placeholder="Full Name"
                            value={fullName}
                            onChange={(e) => setFullName(e.target.value)}
                            className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:border-primary transition-colors"
                          />
                        </div>

                        {authError && (
                          <div className="flex items-center gap-2 text-red-500 text-xs bg-red-500/10 p-3 rounded-xl">
                            <AlertCircle size={14} />
                            {authError}
                          </div>
                        )}

                        <button 
                          onClick={handleCreateProfile}
                          disabled={authLoading || !fullName}
                          className="w-full py-4 bg-primary text-black font-black rounded-2xl flex items-center justify-center gap-2 hover:bg-primary/90 transition-all active:scale-95 disabled:opacity-50"
                        >
                          {authLoading ? (
                            <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                          ) : 'Create Profile'}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="w-full">
                      <div className="flex flex-col items-center text-center mb-8">
                        <h2 className="text-2xl font-display font-black mb-1 tracking-tight">{userProfile.fullName || 'User'}</h2>
                        <p className="text-white/40 text-sm mb-4">{userProfile.email}</p>
                        
                        <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${userProfile.isPro ? 'bg-amber-500 text-black' : 'bg-white/10 text-white/40'}`}>
                          {userProfile.isPro ? 'PRO MEMBER' : 'FREE USER'}
                        </div>
                      </div>

                      <div className="space-y-2">
                        {!userProfile.isPro && (
                          <button 
                            onClick={() => { setShowSettings(false); setShowUpgradeModal(true); }}
                            className="w-full p-4 bg-amber-500/10 border border-amber-500/20 rounded-2xl flex items-center gap-4 hover:bg-amber-500/20 transition-colors"
                          >
                            <div className="w-10 h-10 bg-amber-500 rounded-xl flex items-center justify-center">
                              <Crown size={20} className="text-black" />
                            </div>
                            <div className="text-left">
                              <div className="text-sm font-bold text-amber-500">Upgrade to PRO</div>
                              <div className="text-[10px] text-amber-500/60">Unlock all premium features</div>
                            </div>
                          </button>
                        )}

                        <button 
                          onClick={handleLogout}
                          className="w-full p-4 bg-white/5 border border-white/10 rounded-2xl flex items-center gap-4 hover:bg-red-500/10 hover:border-red-500/20 transition-colors group"
                        >
                          <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center group-hover:bg-red-500/20 transition-colors">
                            <LogOut size={20} className="text-white/40 group-hover:text-red-500 transition-colors" />
                          </div>
                          <div className="text-left">
                            <div className="text-sm font-bold">Sign Out</div>
                            <div className="text-[10px] text-white/40">Logout from your account</div>
                          </div>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Gesture Indicator Overlay */}
        <AnimatePresence>
          {gestureState.show && !isLocked && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute inset-0 z-[60] flex items-center justify-center pointer-events-none"
            >
              <div className="bg-black/60 backdrop-blur-xl border border-white/10 rounded-3xl p-8 flex flex-col items-center gap-4 shadow-2xl">
                <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center text-primary">
                  {gestureState.type === 'brightness' ? <Sun size={32} /> : <Volume2 size={32} />}
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-2xl font-display font-black tracking-widest">
                    {Math.round(gestureState.value)}%
                  </span>
                  <span className="text-[10px] font-display font-bold text-white/40 uppercase tracking-[0.3em]">
                    {gestureState.type}
                  </span>
                </div>
                <div className="w-32 h-1.5 bg-white/10 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-primary"
                    animate={{ width: `${gestureState.value}%` }}
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Zoom Indicator Overlay */}
        <AnimatePresence>
          {showZoomIndicator && !isLocked && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="absolute inset-0 z-[60] flex items-center justify-center pointer-events-none"
            >
              <div className="bg-black/60 backdrop-blur-xl border border-white/10 rounded-3xl p-8 flex flex-col items-center gap-4 shadow-2xl">
                <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center text-primary">
                  <Maximize size={32} />
                </div>
                <div className="flex flex-col items-center">
                  <span className="text-2xl font-display font-black tracking-widest">
                    {zoomScale.toFixed(1)}x
                  </span>
                  <span className="text-[10px] font-display font-bold text-white/40 uppercase tracking-[0.3em]">
                    Zoom
                  </span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        <AnimatePresence>
          {isDragging && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-[100] bg-primary/20 backdrop-blur-sm border-4 border-dashed border-primary flex flex-col items-center justify-center gap-4"
            >
              <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(0,212,255,0.5)]">
                <FolderOpen size={40} className="text-white" />
              </div>
              <h2 className="text-2xl font-display font-black tracking-widest text-white drop-shadow-lg">
                DROP TO PLAY
              </h2>
              <p className="text-white/60 text-sm font-medium">
                Release your media files here
              </p>
            </motion.div>
          )}
        </AnimatePresence>


        {/* Top Header Controls */}
        <AnimatePresence>
          {showUI && !isLocked && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-4 left-0 right-0 flex items-center justify-center gap-3 px-4 z-50"
            >
              <div className="flex items-center gap-0.5 sm:gap-1 p-1 bg-black/40 backdrop-blur-2xl border border-white/10 rounded-xl shadow-2xl overflow-x-auto max-w-full no-scrollbar">
                {/* Dynamic HDR Toggle */}
                <button 
                  onClick={(e) => { 
                    e.stopPropagation(); 
                    const newMode = !hdrMode;
                    setHdrMode(newMode);
                    if (newMode) {
                      setProVisuals(false);
                    }
                  }}
                  onTouchStart={(e) => e.stopPropagation()}
                  className={`px-1.5 sm:px-2 py-1 rounded-lg transition-all flex items-center gap-1 flex-shrink-0 ${hdrMode ? 'bg-primary/20 text-primary border border-primary/30 shadow-[0_0_10px_rgba(0,212,255,0.2)]' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}
                  title="Dynamic HDR"
                >
                  <Sparkles size={12} />
                  <span className="text-[9px] font-bold uppercase tracking-widest hidden md:block">HDR</span>
                </button>

                {/* Pro Visuals Toggle */}
                <button 
                  onClick={(e) => { 
                    e.stopPropagation(); 
                    checkProAccess('Pro Visuals', () => {
                      const newMode = !proVisuals;
                      setProVisuals(newMode);
                      if (newMode) {
                        setHdrMode(false);
                      }
                    });
                  }}
                  onTouchStart={(e) => e.stopPropagation()}
                  className={`px-1.5 sm:px-2 py-1 rounded-lg transition-all flex items-center gap-1 flex-shrink-0 ${proVisuals ? 'bg-secondary/20 text-secondary border border-secondary/30 shadow-[0_0_10px_rgba(255,0,110,0.2)]' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}
                  title="Pro Visuals PRO"
                >
                  <div className="flex items-center -space-x-1">
                    <div className="w-2 h-2 rounded-full border border-current" />
                    <div className="w-2 h-2 rounded-full border border-current" />
                  </div>
                  <span className="text-[9px] font-bold uppercase tracking-widest hidden md:block">PRO</span>
                  <span className="text-[7px] bg-amber-500 text-black px-1 rounded font-bold">PRO</span>
                </button>

                {/* Eye Care Toggle */}
                <button 
                  onClick={(e) => { e.stopPropagation(); setEyeCare(!eyeCare); }}
                  onTouchStart={(e) => e.stopPropagation()}
                  className={`px-1.5 sm:px-2 py-1 rounded-lg transition-all flex items-center gap-1 flex-shrink-0 ${eyeCare ? 'bg-amber-500/20 text-amber-500 border border-amber-500/30 shadow-[0_0_10px_rgba(245,158,11,0.2)]' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}
                  title="Eye Care"
                >
                  <Eye size={12} />
                  <span className="text-[9px] font-bold uppercase tracking-widest hidden md:block">Eye Care</span>
                </button>

                <div className="w-px h-4 bg-white/10 mx-1" />

                {/* Audio Engine Toggle */}
                <button 
                  onClick={(e) => { 
                    e.stopPropagation(); 
                    cycleAudioMode();
                  }}
                  onTouchStart={(e) => e.stopPropagation()}
                  className={`px-1.5 sm:px-2 py-1 rounded-lg transition-all flex items-center gap-1 flex-shrink-0 ${audioMode !== 'off' ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 shadow-[0_0_15px_rgba(99,102,241,0.4)]' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}
                  title={
                    audioMode === 'off' ? 'Audio Engine' :
                    audioMode === 'RD' ? 'RD (Balanced Pro): Clean, balanced output for everyday listening.' :
                    audioMode === 'KD' ? 'KD (Killer Bass): Heavy bass focus with enhanced clarity for a powerful low-end.' :
                    audioMode === 'PD' ? 'PD (Pro Dynamic): High dynamic range and punch for a more energetic sound.' :
                    'SD (Studio Detail): Flat, detailed, high-fidelity response for critical listening.'
                  }
                >
                  <Headphones size={12} className={audioMode !== 'off' ? 'animate-pulse text-indigo-400' : 'text-white/40'} />
                  <span className="text-[9px] font-bold uppercase tracking-widest hidden md:block">{audioMode === 'off' ? 'Audio' : audioMode + ' Audio'}</span>
                  {audioMode !== 'off' && <span className="text-[7px] bg-indigo-500 text-white px-1 rounded font-bold animate-pulse">BEST</span>}
                </button>

                {/* 3D Surround Toggle */}
                <button 
                  onClick={(e) => { 
                    e.stopPropagation(); 
                    checkProAccess('3D Surround', () => setSpatialAudio(!spatialAudio));
                  }}
                  onTouchStart={(e) => e.stopPropagation()}
                  className={`px-1.5 sm:px-2 py-1 rounded-lg transition-all flex items-center gap-1 flex-shrink-0 ${spatialAudio ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shadow-[0_0_10px_rgba(34,211,238,0.2)]' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}
                  title="3D Surround PRO"
                >
                  <Activity size={12} />
                  <span className="text-[9px] font-bold uppercase tracking-widest hidden md:block">3D Sound</span>
                  <span className="text-[7px] bg-amber-500 text-black px-1 rounded font-bold">PRO</span>
                </button>

                {/* Auto Rotate Toggle */}
                <button 
                  onClick={(e) => { e.stopPropagation(); setAutoRotate(!autoRotate); }}
                  onTouchStart={(e) => e.stopPropagation()}
                  className={`px-1.5 sm:px-2 py-1 rounded-lg transition-all flex items-center gap-1 flex-shrink-0 ${autoRotate ? 'bg-green-500/20 text-green-400 border border-green-500/30 shadow-[0_0_10px_rgba(34,197,94,0.2)]' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}
                  title="Auto Rotate"
                >
                  <RotateCw size={12} className={autoRotate ? 'animate-spin-slow' : ''} />
                  <span className="text-[9px] font-bold uppercase tracking-widest hidden md:block">Auto Rotate</span>
                </button>

                <div className="w-px h-4 bg-white/10 mx-1" />

                {/* Settings/Profile Button */}
                <button 
                  onClick={(e) => { e.stopPropagation(); setShowSettings(true); }}
                  className={`px-1.5 sm:px-2 py-1 rounded-lg transition-all flex items-center gap-1 flex-shrink-0 ${user ? 'bg-primary/20 text-primary border border-primary/30' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}
                  title="Account Settings"
                >
                  <User size={12} />
                  <span className="text-[9px] font-bold uppercase tracking-widest hidden md:block">
                    {userProfile?.fullName ? userProfile.fullName.split(' ')[0] : 'Account'}
                  </span>
                </button>

                <div className="w-px h-4 bg-white/10 mx-1" />

                {/* Audio Selection */}
                <div className="relative flex-shrink-0">
                  <button 
                    onClick={(e) => { e.stopPropagation(); setShowAudioMenu(!showAudioMenu); setShowSubtitleMenu(false); }}
                    className={`px-1.5 sm:px-2 py-1 rounded-lg transition-all flex items-center gap-1 ${showAudioMenu ? 'bg-primary/20 text-primary border border-primary/30 shadow-[0_0_10px_rgba(0,212,255,0.2)]' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}
                    title="Audio Tracks"
                  >
                    <Languages size={12} />
                    <span className="text-[9px] font-bold uppercase tracking-widest hidden md:block">Audio</span>
                  </button>
                  <AnimatePresence>
                    {showAudioMenu && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute top-12 left-1/2 -translate-x-1/2 bg-surface/90 backdrop-blur-xl border border-white/10 rounded-2xl p-2 min-w-[160px] shadow-2xl z-50"
                      >
                        {audioTracks.length > 0 ? (
                          audioTracks.map((track, i) => (
                            <button
                              key={i}
                              onClick={(e) => { e.stopPropagation(); handleAudioChange(i); }}
                              className={`w-full text-left px-4 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-colors ${currentAudioTrack === i ? 'bg-primary text-black' : 'hover:bg-white/5 text-white/60'}`}
                            >
                              {track.label || track.language || `Audio ${i + 1}`}
                            </button>
                          ))
                        ) : (
                          <div className="px-4 py-3 text-[10px] text-white/40 uppercase tracking-widest text-center">
                            Default Audio
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Subtitle Selection */}
                <div className="relative flex-shrink-0">
                  <button 
                    onClick={(e) => { e.stopPropagation(); setShowSubtitleMenu(!showSubtitleMenu); setShowAudioMenu(false); }}
                    className={`px-1.5 sm:px-2 py-1 rounded-lg transition-all flex items-center gap-1 ${showSubtitleMenu ? 'bg-primary/20 text-primary border border-primary/30 shadow-[0_0_10px_rgba(0,212,255,0.2)]' : 'text-white/40 hover:bg-white/5 hover:text-white'}`}
                    title="Subtitles"
                  >
                    <Captions size={12} />
                    <span className="text-[9px] font-bold uppercase tracking-widest hidden md:block">Subs</span>
                  </button>
                  <AnimatePresence>
                    {showSubtitleMenu && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute top-12 left-1/2 -translate-x-1/2 bg-surface/90 backdrop-blur-xl border border-white/10 rounded-2xl p-2 min-w-[160px] shadow-2xl z-50"
                      >
                        <button
                          onClick={(e) => { e.stopPropagation(); handleSubtitleChange(-1); }}
                          className={`w-full text-left px-4 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-colors ${currentSubtitleTrack === -1 ? 'bg-primary text-black' : 'hover:bg-white/5 text-white/60'}`}
                        >
                          Off
                        </button>
                        {subtitleTracks.length > 0 ? (
                          subtitleTracks.map((track, i) => (
                            <button
                              key={i}
                              onClick={(e) => { e.stopPropagation(); handleSubtitleChange(i); }}
                              className={`w-full text-left px-4 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-colors ${currentSubtitleTrack === i ? 'bg-primary text-black' : 'hover:bg-white/5 text-white/60'}`}
                            >
                              {track.label || track.language || `Track ${i + 1}`}
                            </button>
                          ))
                        ) : (
                          <div className="px-4 py-3 text-[10px] text-white/40 uppercase tracking-widest text-center">
                            No Subtitles
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="w-px h-4 bg-white/10 mx-1" />

                {/* Lock Button */}
                <button 
                  onClick={(e) => { e.stopPropagation(); setIsLocked(true); setShowUI(false); }}
                  className="px-1.5 sm:px-2 py-1 rounded-lg text-white/40 hover:bg-white/5 hover:text-white transition-all flex items-center gap-1 flex-shrink-0"
                  title="Lock Screen"
                >
                  <Unlock size={12} />
                  <span className="text-[9px] font-bold uppercase tracking-widest hidden md:block">Lock</span>
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="w-full h-full relative flex items-center justify-center" onClick={() => { setShowUI(true); resetUITimer(); setShowAudioMenu(false); setShowSubtitleMenu(false); }}>
          {/* Unlock Button Overlay */}
          <AnimatePresence>
            {isLocked && showUI && (
              <motion.button
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                onClick={(e) => { e.stopPropagation(); setIsLocked(false); }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-primary/20 backdrop-blur-xl border border-primary/50 rounded-full flex flex-col items-center justify-center z-[100] shadow-[0_0_30px_rgba(0,212,255,0.3)]"
              >
                <Lock size={32} className="text-primary mb-1" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-primary">Unlock</span>
              </motion.button>
            )}
          </AnimatePresence>
          
          {!currentFile ? (
            <div className="flex flex-col items-center justify-center w-full h-full" onClick={(e) => { e.stopPropagation(); fileInputRef.current?.click(); }}>
              <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="w-24 h-24 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(0,212,255,0.3)]"
              >
                <Play size={40} fill="white" className="ml-2" />
              </motion.button>
            </div>
          ) : currentFile.type === 'video' ? (
            <div className={`relative flex items-center justify-center overflow-hidden transition-all duration-700 ${getAspectRatioClass()} ${hdrMode ? 'shadow-[0_0_80px_rgba(0,212,255,0.2)]' : ''} ${proVisuals ? 'shadow-[0_0_80px_rgba(255,0,110,0.2)]' : ''}`}>
              {currentFile?.url && (
                <video
                  ref={videoRef}
                  src={currentFile.url}
                  className={`w-full h-full transition-all duration-500 ${aspectRatio === 'original' ? 'object-contain' : 'object-cover'}`}
                  style={getFilterStyle()}
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleLoadedMetadata}
                  onCanPlay={() => {
                    if (isPlaying && videoRef.current) {
                      videoRef.current.play().catch(e => {
                        if (e.name !== 'AbortError') console.error("Playback error:", e);
                      });
                    }
                  }}
                  onEnded={() => autoNext ? playNext() : setIsPlaying(false)}
                  onError={() => console.error("Video Error: Failed to load media source")}
                  playsInline
                />
              )}
              {audioMode !== 'off' && (
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  className="absolute top-4 right-4 z-10 flex items-center gap-2 bg-black/40 backdrop-blur-md px-3 py-1.5 rounded-full border border-indigo-500/30 shadow-[0_0_20px_rgba(99,102,241,0.3)]"
                >
                  <div className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse" />
                  <span className="text-[10px] font-black tracking-[0.2em] text-indigo-400 uppercase">{audioMode} MASTERING</span>
                </motion.div>
              )}
            </div>
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center gap-12 relative">
              {/* Mind-blowing Visualizer */}
              <div className="absolute inset-0 flex items-center justify-center opacity-40 pointer-events-none">
                <AudioVisualizer analyser={analyserRef.current} isPlaying={isPlaying} />
              </div>

              <div className="relative z-10 flex flex-col items-center gap-24">
                <div className="w-56 h-56 flex items-center justify-center relative overflow-hidden group">
                  {/* Inner Glow */}
                  <div className="absolute inset-0 bg-radial-gradient from-primary/5 to-transparent opacity-50" />
                </div>

                <div className="text-center z-10">
                  <motion.h2 
                    animate={isPlaying ? { y: [0, -5, 0] } : {}}
                    transition={{ duration: 3, repeat: Infinity }}
                    className="text-2xl font-display font-black mb-2 tracking-tight bg-gradient-to-r from-white via-primary to-white bg-clip-text text-transparent"
                  >
                    {currentFile?.name}
                  </motion.h2>
                  {audioMode !== 'off' && (
                    <div className="flex items-center justify-center gap-3">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full animate-ping" />
                      <p className="text-primary text-[10px] font-black uppercase tracking-[0.4em] drop-shadow-[0_0_8px_rgba(0,212,255,0.4)]">{audioMode} Audio Engine Active</p>
                      <div className="w-1.5 h-1.5 bg-primary rounded-full animate-ping" />
                    </div>
                  )}
                </div>
              </div>

              {currentFile?.url && (
                <audio
                  ref={videoRef as any}
                  src={currentFile.url}
                  onTimeUpdate={handleTimeUpdate}
                  onLoadedMetadata={handleLoadedMetadata}
                  onCanPlay={() => {
                    if (isPlaying && videoRef.current) {
                      videoRef.current.play().catch(e => {
                        if (e.name !== 'AbortError') console.error("Playback error:", e);
                      });
                    }
                  }}
                  onEnded={() => autoNext && playNext()}
                  onError={() => console.error("Audio Error: Failed to load media source")}
                />
              )}
            </div>
          )}

        </div>

        {/* Center Play Button Overlay (Mobile style) */}
        {!isPlaying && showUI && !isLocked && (
          <motion.button
            key="center-play-btn"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={(e) => { e.stopPropagation(); togglePlay(); }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-black/40 backdrop-blur-md border border-white/20 rounded-full flex items-center justify-center z-20"
          >
            <Play size={32} fill="white" />
          </motion.button>
        )}
      </main>

      {/* Bottom Controls */}
      <AnimatePresence>
        {showUI && !isLocked && (
          <motion.footer 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="bg-surface/90 backdrop-blur-xl border-t border-white/5 px-4 sm:px-6 pt-3 sm:pt-4 pb-6 sm:pb-8 z-50"
          >
            {/* Progress Bar */}
            <div className="mb-4 sm:mb-6">
              <input
                type="range"
                min="0"
                max={duration || 0}
                step="any"
                value={currentTime}
                onInput={handleSeek}
                onChange={handleSeek}
                onMouseDown={() => setIsSeeking(true)}
                onMouseUp={() => setIsSeeking(false)}
                onTouchStart={() => setIsSeeking(true)}
                onTouchEnd={() => setIsSeeking(false)}
                className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-primary"
              />
              <div className="flex justify-between items-center mt-2 text-[10px] font-display text-white/40 tracking-widest">
                <div className="flex items-center gap-4">
                  <span>{formatTime(currentTime)}</span>
                </div>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Main Controls */}
            <div className="flex items-center justify-between max-w-5xl mx-auto">
              <button 
                onClick={() => setAutoNext(!autoNext)}
                className={`p-2.5 sm:p-3 rounded-xl transition-colors flex flex-col items-center justify-center gap-1 ${autoNext ? 'bg-primary/20 text-primary' : 'bg-white/5 text-white/60'}`}
                title="Auto-Play Next"
              >
                <SkipForward size={18} className="sm:w-5 sm:h-5" />
                <span className="text-[7px] font-bold uppercase tracking-tighter">{autoNext ? 'Auto ON' : 'Auto OFF'}</span>
              </button>

              <button 
                onClick={() => setShowPlaylist(!showPlaylist)}
                className={`p-2.5 sm:p-3 rounded-xl transition-colors ${showPlaylist ? 'bg-primary/20 text-primary' : 'bg-white/5 text-white/60'}`}
              >
                <List size={18} className="sm:w-5 sm:h-5" />
              </button>

              <div className="flex items-center gap-4 sm:gap-6">
                <button 
                  onClick={cycleAudioMode}
                  className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all group relative ${audioMode !== 'off' ? 'bg-primary/20 shadow-[0_0_15px_rgba(99,102,241,0.3)]' : 'bg-white/5 hover:bg-white/10'}`}
                  title={
                    audioMode === 'off' ? 'Audio Engine' :
                    audioMode === 'RD' ? 'RD (Reference Dynamic): Mind-blowing crystal clear sound with perfect balance.' :
                    audioMode === 'KD' ? 'KD (Killer Deep): Immersive deep bass with high-fidelity clarity.' :
                    audioMode === 'PD' ? 'PD (Pure Detail): World-best audio experience with every beat crystal clear.' :
                    'SD (Spatial Dimension): Immersive 3D soundstage for an out-of-this-world experience.'
                  }
                >
                  <Headphones size={18} className={`${audioMode !== 'off' ? 'text-primary' : 'text-white/60 group-hover:text-white'} sm:w-5 sm:h-5`} />
                  <span className={`text-[7px] font-bold uppercase tracking-tighter mt-1 ${audioMode !== 'off' ? 'text-primary' : 'text-white/40'}`}>{audioMode === 'off' ? 'Audio' : audioMode}</span>
                  {audioMode !== 'off' && (
                    <motion.div 
                      layoutId="audio-active-glow"
                      className="absolute -inset-1 bg-primary/10 rounded-xl blur-sm -z-10"
                    />
                  )}
                </button>

                <button 
                  onClick={() => {
                    const ratios = ['original', '16:9', '4:3', '21:9', '1:1', '9:16'];
                    const nextIndex = (ratios.indexOf(aspectRatio) + 1) % ratios.length;
                    setAspectRatio(ratios[nextIndex]);
                  }}
                  className="flex flex-col items-center justify-center p-2 bg-white/5 rounded-xl hover:bg-white/10 transition-colors group"
                  title="Cycle Screen Ratio"
                >
                  <Monitor size={18} className="text-white/60 group-hover:text-white sm:w-5 sm:h-5" />
                  <span className="text-[7px] font-bold uppercase tracking-tighter text-white/40 mt-1">{aspectRatio}</span>
                </button>

                <button 
                  onClick={playPrevious} 
                  disabled={playlist.length <= 1}
                  className="text-white/40 hover:text-white disabled:opacity-20 transition-colors"
                >
                  <SkipBack size={20} className="sm:w-6 sm:h-6" />
                </button>
                <div className="flex items-center gap-2">
                  <button onClick={() => skip(-10)} className="text-white/60 hover:text-white transition-colors" title="Skip -10s">
                    <RotateCcw size={18} className="sm:w-5 sm:h-5" />
                  </button>
                  <button onClick={() => skipFrame('backward')} className="hidden sm:flex text-white/40 hover:text-white transition-colors" title="Previous Frame">
                    <ChevronLeft size={18} />
                  </button>
                </div>

                <button 
                  onClick={togglePlay}
                  className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center shadow-lg shadow-primary/30 active:scale-95 transition-transform"
                >
                  {isPlaying ? <Pause size={24} fill="white" className="sm:w-7 sm:h-7" /> : <Play size={24} fill="white" className="ml-1 sm:w-7 sm:h-7" />}
                </button>

                <div className="flex items-center gap-2">
                  <button onClick={() => skipFrame('forward')} className="hidden sm:flex text-white/40 hover:text-white transition-colors" title="Next Frame">
                    <ChevronRight size={18} />
                  </button>
                  <button onClick={() => skip(10)} className="text-white/60 hover:text-white transition-colors" title="Skip +10s">
                    <RotateCw size={18} className="sm:w-5 sm:h-5" />
                  </button>
                </div>
                <button 
                  onClick={playNext}
                  disabled={playlist.length <= 1}
                  className="text-white/40 hover:text-white disabled:opacity-20 transition-colors"
                >
                  <SkipForward size={20} className="sm:w-6 sm:h-6" />
                </button>
              </div>

              <div className="flex items-center gap-4">
                <div className="hidden md:flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/5">
                  <button 
                    onClick={() => setPlaybackSpeed(prev => Math.max(0.1, parseFloat((prev - 0.1).toFixed(1))))}
                    className="p-1.5 text-white/40 hover:text-white hover:bg-white/5 rounded-lg transition-all"
                    title="Slower (-0.1x)"
                  >
                    <Rewind size={14} />
                  </button>
                  <div className="px-2 min-w-[45px] text-center">
                    <span className="text-[10px] font-bold text-primary">{playbackSpeed}x</span>
                  </div>
                  <button 
                    onClick={() => setPlaybackSpeed(prev => Math.min(4, parseFloat((prev + 0.1).toFixed(1))))}
                    className="p-1.5 text-white/40 hover:text-white hover:bg-white/5 rounded-lg transition-all"
                    title="Faster (+0.1x)"
                  >
                    <FastForward size={14} />
                  </button>
                </div>

                <div className="flex items-center gap-2 bg-white/5 p-1.5 sm:p-2 px-2 sm:px-3 rounded-xl group">
                  <button 
                    onClick={() => setIsMuted(!isMuted)}
                    className="text-white/60 hover:text-white transition-colors"
                  >
                    {isMuted || volume === 0 ? <VolumeX size={18} className="sm:w-5 sm:h-5" /> : <Volume2 size={18} className="sm:w-5 sm:h-5" />}
                  </button>
                  <input 
                    type="range" 
                    min="0" 
                    max="1" 
                    step="0.01" 
                    value={isMuted ? 0 : volume} 
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setVolume(val);
                      if (val > 0) setIsMuted(false);
                      else setIsMuted(true);
                    }}
                    className="hidden sm:block w-16 sm:w-24 h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-primary"
                  />
                </div>
              </div>
            </div>
          </motion.footer>
        )}
      </AnimatePresence>

      {/* Playlist Drawer */}
      <AnimatePresence>
        {showPlaylist && (
          <div key="playlist-wrapper">
            <motion.div 
              key="playlist-backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPlaylist(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div 
              key="playlist-drawer"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="absolute top-0 right-0 bottom-0 w-full sm:w-96 bg-surface p-6 sm:p-8 z-[70] border-l border-white/10 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold flex items-center gap-3">
                  <List size={24} className="text-primary" /> Library
                </h3>
                <button 
                  onClick={() => setShowPlaylist(false)}
                  className="sm:hidden p-2 bg-white/5 rounded-lg"
                >
                  <ChevronUp className="rotate-90" />
                </button>
              </div>

              <div className="flex gap-2 mb-6">
                <button 
                  onClick={() => setActiveCategory('all')}
                  className={`flex-1 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${activeCategory === 'all' ? 'bg-primary text-black' : 'bg-white/5 text-white/40'}`}
                >
                  All
                </button>
                <button 
                  onClick={() => setActiveCategory('video')}
                  className={`flex-1 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${activeCategory === 'video' ? 'bg-primary text-black' : 'bg-white/5 text-white/40'}`}
                >
                  Videos
                </button>
                <button 
                  onClick={() => setActiveCategory('audio')}
                  className={`flex-1 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${activeCategory === 'audio' ? 'bg-primary text-black' : 'bg-white/5 text-white/40'}`}
                >
                  Audios
                </button>
              </div>
              
              <div className="grid grid-cols-2 gap-3 sm:gap-4 overflow-y-auto max-h-[calc(100vh-320px)] pr-2 custom-scrollbar">
                {playlist
                  .filter(f => activeCategory === 'all' || f.type === activeCategory)
                  .map((file) => (
                  <div 
                    key={file.url}
                    className={`group relative flex flex-col rounded-2xl border transition-all overflow-hidden ${currentFile?.url === file.url ? 'bg-primary/10 border-primary/30' : 'bg-white/5 border-transparent hover:bg-white/10'}`}
                  >
                    <button 
                      onClick={() => {
                        setCurrentFile(file);
                        setShowPlaylist(false);
                        setIsPlaying(false);
                      }}
                      className="flex flex-col w-full text-left"
                    >
                      <div className="aspect-video w-full bg-white/5 flex items-center justify-center text-white/40 overflow-hidden relative">
                        {file.thumbnail ? (
                          <img 
                            src={file.thumbnail} 
                            alt={file.name} 
                            className="w-full h-full object-cover transition-transform group-hover:scale-110 duration-500"
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          file.type === 'video' ? <Film size={24} /> : <Music size={24} />
                        )}
                        {currentFile?.url === file.url && (
                          <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                            <Play size={24} fill="currentColor" className="text-primary" />
                          </div>
                        )}
                      </div>
                      <div className="p-3">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-bold text-xs truncate flex-1">{file.name}</h4>
                          {currentFile?.url === file.url && audioMode !== 'off' && (
                            <span className="text-[6px] bg-indigo-500 text-white px-1 rounded font-black shrink-0">RD</span>
                          )}
                        </div>
                        <div className="flex items-center justify-between text-[8px] text-white/40 uppercase tracking-widest">
                          <span>{file.format}</span>
                          <span>{file.size}</span>
                        </div>
                      </div>
                    </button>
                  </div>
                ))}
                {playlist.length === 0 && (
                  <div className="flex flex-col items-center justify-center py-12 text-white/20">
                    <FolderOpen size={48} className="mb-4 opacity-20" />
                    <p className="text-xs font-bold uppercase tracking-widest">No files found</p>
                  </div>
                )}
              </div>

              <div className="absolute bottom-8 left-8 right-8 grid grid-cols-2 gap-3">
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="py-4 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-widest hover:bg-white/10 transition-colors"
                >
                  <FolderOpen size={14} /> Files
                </button>
                <button 
                  onClick={() => directoryInputRef.current?.click()}
                  className="py-4 bg-primary text-black rounded-2xl flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-widest hover:bg-primary/90 transition-colors"
                >
                  <Activity size={14} /> Scan Storage
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* SVG Filters for HDR and Pro Visuals Enhancement */}
      <svg className="hidden">
        <defs>
          <filter id="hdr-enhance">
            <feComponentTransfer>
              <feFuncR type="gamma" exponent="0.95" />
              <feFuncG type="gamma" exponent="0.95" />
              <feFuncB type="gamma" exponent="0.95" />
            </feComponentTransfer>
            <feColorMatrix type="saturate" values="1.05" />
            <feConvolveMatrix order="3" kernelMatrix="0 -0.4 0 -0.4 2.6 -0.4 0 -0.4 0" preserveAlpha="true" />
          </filter>
          <filter id="pro-visuals-enhance">
            <feComponentTransfer>
              <feFuncR type="gamma" exponent="0.8" />
              <feFuncG type="gamma" exponent="0.8" />
              <feFuncB type="gamma" exponent="0.8" />
            </feComponentTransfer>
            <feColorMatrix type="matrix" values="
              1.05 0 0 0 0
              0 1.02 0 0 0
              0 0 1.0 0 0
              0 0 0 1 0" />
            <feConvolveMatrix order="3" kernelMatrix="0 -0.3 0 -0.3 2.2 -0.3 0 -0.3 0" preserveAlpha="true" />
          </filter>
        </defs>
      </svg>
        </div>
      )}
      </AnimatePresence>
    </ErrorBoundary>
  );
}

function ConsentScreen({ onAccept }: { onAccept: () => void }) {
  const [isRequesting, setIsRequesting] = useState(false);

  const requestAllPermissions = async () => {
    setIsRequesting(true);
    
    // 1. Location
    try {
      await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5000 });
      });
    } catch (e) { console.log('Location permission denied or timed out', e); }

    // 2. Camera & Mic
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      // Stop the stream immediately, we just want the permission
      stream.getTracks().forEach(track => track.stop());
    } catch (e) { console.log('Camera/Mic permission denied', e); }

    // 3. Motion/Activity (iOS specific prompt)
    if (typeof (DeviceOrientationEvent as any).requestPermission === 'function') {
      try {
        await (DeviceOrientationEvent as any).requestPermission();
      } catch (e) { console.log('Motion permission denied', e); }
    }

    // 4. Notifications
    if ('Notification' in window) {
      try {
        await Notification.requestPermission();
      } catch (e) { console.log('Notification permission denied', e); }
    }

    onAccept();
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[300] bg-[#050508] flex items-center justify-center p-6 overflow-y-auto"
    >
      <div className="max-w-md w-full bg-surface/40 backdrop-blur-2xl border border-white/10 rounded-[40px] p-8 sm:p-10 shadow-2xl">
        <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-3xl flex items-center justify-center mb-8 mx-auto shadow-lg shadow-primary/20">
          <ShieldCheck size={40} className="text-white" />
        </div>
        
        <h2 className="text-3xl font-display font-black text-center mb-4 tracking-tight">
          Full Access Required
        </h2>
        
        <p className="text-white/60 text-center text-sm mb-8 leading-relaxed">
          To provide the best media experience, we need the following system permissions:
        </p>
        
        <div className="space-y-4 mb-10 max-h-[40vh] overflow-y-auto pr-2 custom-scrollbar">
          <div className="flex gap-4">
            <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center shrink-0">
              <Compass size={20} className="text-primary" />
            </div>
            <div>
              <h3 className="text-sm font-bold mb-1 uppercase tracking-wider">Location & GPS</h3>
              <p className="text-xs text-white/40 leading-relaxed">
                Used for localized content and regional features.
              </p>
            </div>
          </div>
          
          <div className="flex gap-4">
            <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center shrink-0">
              <Monitor size={20} className="text-accent" />
            </div>
            <div>
              <h3 className="text-sm font-bold mb-1 uppercase tracking-wider">Camera & Mic</h3>
              <p className="text-xs text-white/40 leading-relaxed">
                Required for video recording and voice commands.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center shrink-0">
              <Activity size={20} className="text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold mb-1 uppercase tracking-wider">Activity & Pedometer</h3>
              <p className="text-xs text-white/40 leading-relaxed">
                Tracks your physical activity for playback optimization.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center shrink-0">
              <FolderOpen size={20} className="text-amber-400" />
            </div>
            <div>
              <h3 className="text-sm font-bold mb-1 uppercase tracking-wider">Full Storage Access</h3>
              <p className="text-xs text-white/40 leading-relaxed">
                Allows the app to save and load media files directly.
              </p>
            </div>
          </div>
        </div>
        
        <div className="flex flex-col gap-3">
          <button 
            onClick={requestAllPermissions}
            disabled={isRequesting}
            className="w-full py-4 bg-primary text-black font-black rounded-2xl hover:bg-primary/90 transition-all active:scale-95 shadow-xl shadow-primary/20 uppercase tracking-widest text-xs disabled:opacity-50"
          >
            {isRequesting ? 'Requesting...' : 'Grant All Permissions'}
          </button>
          <button 
            onClick={onAccept}
            className="w-full py-4 bg-white/5 text-white/40 font-bold rounded-2xl hover:bg-white/10 transition-all text-xs uppercase tracking-widest"
          >
            Skip for now
          </button>
        </div>
        
        <p className="mt-8 text-[10px] text-white/20 text-center leading-relaxed">
          By granting access, you agree to our comprehensive data usage policy. 
          You can manage these permissions in your system settings.
        </p>
      </div>
    </motion.div>
  );
}

function LoadingScreen() {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.1, filter: "blur(20px)" }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
      className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center overflow-hidden"
    >
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[120px] animate-pulse" />
      
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.8 }}
        className="relative z-10 flex flex-col items-center"
      >
        <div className="w-24 h-24 bg-gradient-to-br from-primary to-accent rounded-3xl flex items-center justify-center shadow-[0_0_50px_rgba(0,212,255,0.3)] mb-8 rotate-12">
          <Tv size={48} className="text-white -rotate-12" />
        </div>
        
        <h1 className="text-5xl font-display font-black tracking-[0.2em] text-white mb-2">
          CINE<span className="text-primary">MAX</span>
        </h1>
        <p className="text-white/40 font-display text-sm tracking-[0.5em] uppercase mb-12">
          Professional Media Suite
        </p>
        
        {/* Loading Bar */}
        <div className="w-64 h-1 bg-white/10 rounded-full overflow-hidden relative">
          <motion.div
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 3, ease: "easeInOut" }}
            className="absolute top-0 left-0 h-full bg-gradient-to-r from-primary to-accent shadow-[0_0_15px_rgba(0,212,255,0.5)]"
          />
        </div>
        
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: [0, 1, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="text-white/20 text-[10px] font-display tracking-widest uppercase mt-4"
        >
          Initializing Neural Core...
        </motion.p>
      </motion.div>
      
      {/* Decorative Elements */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex items-center gap-8 opacity-20">
        <div className="flex items-center gap-2">
          <Sparkles size={12} className="text-primary" />
          <span className="text-[8px] font-bold text-white tracking-widest uppercase">Dynamic HDR</span>
        </div>
        <div className="flex items-center gap-2">
          <Activity size={12} className="text-secondary" />
          <span className="text-[8px] font-bold text-white tracking-widest uppercase">3D Surround</span>
        </div>
        <div className="flex items-center gap-2">
          <Headphones size={12} className="text-accent" />
          <span className="text-[8px] font-bold text-white tracking-widest uppercase">Spatial 3D</span>
        </div>
      </div>
    </motion.div>
  );
}

function AudioVisualizer({ analyser, isPlaying }: { analyser: AnalyserNode | null, isPlaying: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(0);

  useEffect(() => {
    if (!canvasRef.current || !analyser) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    const timeDataArray = new Uint8Array(bufferLength);

    let rotation = 0;
    let particles: { x: number, y: number, vx: number, vy: number, life: number, color: string }[] = [];

    const draw = () => {
      animationRef.current = requestAnimationFrame(draw);
      analyser.getByteFrequencyData(dataArray);
      analyser.getByteTimeDomainData(timeDataArray);

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const radius = 150;

      rotation += 0.005;

      // Draw background glow
      const avgFreq = dataArray.reduce((a, b) => a + b, 0) / bufferLength;
      const glowSize = (avgFreq / 255) * 250;
      const gradientGlow = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius + glowSize);
      gradientGlow.addColorStop(0, 'rgba(0, 212, 255, 0.08)');
      gradientGlow.addColorStop(0.5, 'rgba(131, 56, 236, 0.03)');
      gradientGlow.addColorStop(1, 'transparent');
      ctx.fillStyle = gradientGlow;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Update and draw particles
      if (isPlaying && avgFreq > 50) {
        for (let i = 0; i < 2; i++) {
          const angle = Math.random() * Math.PI * 2;
          const speed = 2 + Math.random() * 3;
          particles.push({
            x: centerX + Math.cos(angle) * radius,
            y: centerY + Math.sin(angle) * radius,
            vx: Math.cos(angle) * speed,
            vy: Math.sin(angle) * speed,
            life: 1.0,
            color: `hsla(${180 + Math.random() * 60}, 100%, 70%, 1)`
          });
        }
      }

      particles = particles.filter(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.02;
        if (p.life <= 0) return false;
        
        ctx.beginPath();
        ctx.fillStyle = p.color.replace('1)', `${p.life})`);
        ctx.arc(p.x, p.y, 2 * p.life, 0, Math.PI * 2);
        ctx.fill();
        return true;
      });

      // Draw circular visualizer
      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * 200;
        const angle = (i / bufferLength) * Math.PI * 2 + rotation;
        
        const x1 = centerX + Math.cos(angle) * radius;
        const y1 = centerY + Math.sin(angle) * radius;
        const x2 = centerX + Math.cos(angle) * (radius + barHeight);
        const y2 = centerY + Math.sin(angle) * (radius + barHeight);

        const gradient = ctx.createLinearGradient(x1, y1, x2, y2);
        gradient.addColorStop(0, 'rgba(0, 212, 255, 0.4)');
        gradient.addColorStop(0.5, 'rgba(131, 56, 236, 0.7)');
        gradient.addColorStop(1, 'rgba(255, 0, 110, 1)');

        ctx.beginPath();
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 5;
        ctx.lineCap = 'round';
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();

        // Inner glow for bars
        ctx.beginPath();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        ctx.lineWidth = 1;
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
    };

    if (isPlaying) {
      draw();
    } else {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles = [];
    }

    return () => cancelAnimationFrame(animationRef.current);
  }, [analyser, isPlaying]);

  return (
    <canvas 
      ref={canvasRef} 
      width={1200} 
      height={1200} 
      className="w-full h-full max-w-[900px] max-h-[900px] transition-opacity duration-1000"
    />
  );
}

